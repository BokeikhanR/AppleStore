//
//  BuyVC.swift
//  16_UIImageView
//
//  Created by admin on 09.07.2021.
//

import UIKit

final class BuyVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Купить"
        view.backgroundColor = .black
    }

}
